/* File: misc/rtos_hooks.c */
#include "../CONFIG.h"

void vApplicationStackOverflowHook(TaskHandle_t xTask, char *pcTaskName) {
    (void)xTask;
    printf("[FATAL] Stack overflow in task: %s\r\n", pcTaskName ? pcTaskName : "?");
    taskDISABLE_INTERRUPTS();
    for (;;)
        ;
}

void vApplicationMallocFailedHook(void) {
    printf("[FATAL] Malloc failed\r\n");
    taskDISABLE_INTERRUPTS();
    for (;;)
        ;
}

/* Strong definition to satisfy configASSERT() -> vAssertCalled() */
void vAssertCalled(const char *file, int line) {
    /* Halt the system in a safe, debuggable state. */
    taskDISABLE_INTERRUPTS();

    /* Best-effort log; safe even if scheduler not started yet. */
    (void)printf("[ASSERT] %s:%d\r\n", file ? file : "?", line);

    /* Trap here so a debugger can inspect. Change to NVIC_SystemReset() if desired. */
    volatile int block = 1;
    while (block) {
        __asm volatile("nop");
    }
}