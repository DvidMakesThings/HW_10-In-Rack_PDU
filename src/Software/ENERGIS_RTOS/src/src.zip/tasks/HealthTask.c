#include "../CONFIG.h"

/* Use your non-blocking logger. Fall back to no-op if missing. */
#ifndef HEALTH_LOGI
#ifdef INFO_PRINT
#define HEALTH_LOGI(...) INFO_PRINT(__VA_ARGS__)
#else
#define HEALTH_LOGI(...)                                                                           \
    do {                                                                                           \
    } while (0)
#endif
#endif
#ifndef HEALTH_LOGW
#ifdef WARN_PRINT
#define HEALTH_LOGW(...) WARN_PRINT(__VA_ARGS__)
#else
#define HEALTH_LOGW(...)                                                                           \
    do {                                                                                           \
    } while (0)
#endif
#endif

#ifndef HEALTH_PERIOD_MS
#define HEALTH_PERIOD_MS 1000u
#endif
#ifndef HEALTH_WARMUP_MS
#define HEALTH_WARMUP_MS 15000u
#endif
#ifndef HEALTH_SILENCE_MS
#define HEALTH_SILENCE_MS 8000u
#endif
#ifndef HEALTH_BLOCK_RING_SIZE
#define HEALTH_BLOCK_RING_SIZE 32u
#endif

typedef struct {
    uint32_t tick_ms;
    char tag[24];
    uint16_t waited_ms;
} block_evt_t;

typedef struct {
    TaskHandle_t handle;
    const char *name;
    uint32_t last_seen_ms;
    bool registered;
} task_meta_t;

static task_meta_t s_meta[HEALTH_ID_MAX];
static block_evt_t s_block_ring[HEALTH_BLOCK_RING_SIZE];
static volatile uint32_t s_block_w = 0;

static TaskHandle_t s_health_handle = NULL;
static bool s_watchdog_armed = false;
static uint32_t s_start_ms = 0;

static inline uint32_t now_ms(void) { return to_ms_since_boot(get_absolute_time()); }

#if (INCLUDE_uxTaskGetStackHighWaterMark == 1)
static void log_stack_watermarks(void) {
    for (int i = 0; i < HEALTH_ID_MAX; ++i) {
        if (s_meta[i].registered && s_meta[i].handle) {
            UBaseType_t hw = uxTaskGetStackHighWaterMark(s_meta[i].handle);
            HEALTH_LOGI("[Health] stackHW %s: %lu words\r\n",
                        s_meta[i].name ? s_meta[i].name : "task", (unsigned long)hw);
        }
    }
}
#else
static void log_stack_watermarks(void) {}
#endif

#if (configUSE_MALLOC_FAILED_HOOK == 1)
extern size_t xPortGetFreeHeapSize(void);
#endif

static void log_heap_free(void) {
#if (configUSE_MALLOC_FAILED_HOOK == 1)
    size_t freeb = xPortGetFreeHeapSize();
    HEALTH_LOGI("[Health] heap_free=%lu bytes\r\n", (unsigned long)freeb);
#endif
}

static void dump_block_ring(void) {
    uint32_t w = s_block_w;
    uint32_t n = (w > HEALTH_BLOCK_RING_SIZE) ? HEALTH_BLOCK_RING_SIZE : w;
    if (n == 0)
        return;
    HEALTH_LOGI("[Health] recent blocked events (newest last):\r\n");
    uint32_t start = (w >= n) ? (w - n) : 0;
    for (uint32_t i = 0; i < n; ++i) {
        const block_evt_t *e = &s_block_ring[(start + i) % HEALTH_BLOCK_RING_SIZE];
        HEALTH_LOGI("  t=%lu ms tag=%s waited=%u ms\r\n", (unsigned long)e->tick_ms,
                    e->tag[0] ? e->tag : "-", (unsigned)e->waited_ms);
    }
}

static bool all_tasks_have_heartbeat_once(void) {
    for (int i = 0; i < HEALTH_ID_MAX; ++i) {
        if (s_meta[i].registered && s_meta[i].last_seen_ms == 0)
            return false;
    }
    return true;
}

static bool all_tasks_within_silence(uint32_t now) {
    for (int i = 0; i < HEALTH_ID_MAX; ++i) {
        if (!s_meta[i].registered)
            continue;
        if (s_meta[i].last_seen_ms == 0)
            return false;
        uint32_t dt = now - s_meta[i].last_seen_ms;
        if (dt > HEALTH_SILENCE_MS) {
            HEALTH_LOGW("[Health] stale: %s dt=%lu ms (> %u)\r\n",
                        s_meta[i].name ? s_meta[i].name : "task", (unsigned long)dt,
                        (unsigned)HEALTH_SILENCE_MS);
            return false;
        }
    }
    return true;
}

static void health_task(void *arg) {
    (void)arg;
    s_start_ms = now_ms();

    const TickType_t period = pdMS_TO_TICKS(HEALTH_PERIOD_MS);
    TickType_t last = xTaskGetTickCount();

    for (;;) {
        vTaskDelayUntil(&last, period);

        /* Light diagnostics only. Keep logs short to avoid back-pressure. */
        log_stack_watermarks();
        log_heap_free();
        dump_block_ring();

        uint32_t t = now_ms();

        if (!s_watchdog_armed) {
            bool warmup_elapsed = (t - s_start_ms) >= HEALTH_WARMUP_MS;
            if (all_tasks_have_heartbeat_once() || warmup_elapsed) {
                /* Arm the watchdog now. Timeout == silence window. */
                watchdog_enable(HEALTH_SILENCE_MS, 1);
                s_watchdog_armed = true;
                HEALTH_LOGI("[Health] watchdog armed (timeout=%u ms, warmup_elapsed=%d)\r\n",
                            (unsigned)HEALTH_SILENCE_MS, warmup_elapsed ? 1 : 0);
            } else {
                continue;
            }
        }

        if (all_tasks_within_silence(t)) {
            watchdog_update();
        } else {
            /* Do not feed; let WDG bite if the stall persists. */
            HEALTH_LOGW("[Health] watchdog withheld\r\n");
        }
    }
}

/* Public API */
void HealthTask_Start(void) {
    if (s_health_handle)
        return;
    /* Priority: below Console/Net. Adjust if needed. */
    xTaskCreate(health_task, "Health", 1024, NULL, tskIDLE_PRIORITY + 1, &s_health_handle);
}

void Health_RegisterTask(health_id_t id, TaskHandle_t h, const char *name) {
    if ((int)id < 0 || (int)id >= HEALTH_ID_MAX)
        return;
    s_meta[id].handle = h;
    s_meta[id].name = name ? name : "task";
    s_meta[id].last_seen_ms = 0;
    s_meta[id].registered = (h != NULL);
}

void Health_Heartbeat(health_id_t id) {
    if ((int)id < 0 || (int)id >= HEALTH_ID_MAX)
        return;
    if (!s_meta[id].registered)
        return;
    s_meta[id].last_seen_ms = now_ms();
}

void Health_RecordBlocked(const char *tag, uint32_t waited_ms) {
    uint32_t i = __atomic_fetch_add(&s_block_w, 1, __ATOMIC_RELAXED);
    block_evt_t *e = &s_block_ring[i % HEALTH_BLOCK_RING_SIZE];
    e->tick_ms = now_ms();
    e->waited_ms = (uint16_t)(waited_ms > 0xFFFF ? 0xFFFF : waited_ms);
    if (tag) {
        strncpy(e->tag, tag, sizeof(e->tag) - 1);
        e->tag[sizeof(e->tag) - 1] = 0;
    } else {
        e->tag[0] = 0;
    }
}
