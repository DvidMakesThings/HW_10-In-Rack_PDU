/**
 * @file snmp_networkCtrl.c
 * @author DvidMakesThings - David Sipos
 *
 * @defgroup snmp02 2. SNMP Agent - Network configuration (RTOS)
 * @ingroup snmp
 * @brief Expose persisted network config (EEPROM) as SNMP strings.
 * @{
 *
 * @version 1.1.0
 * @date 2025-11-08
 *
 * @details
 * Reads the user/network configuration from EEPROM using storage helpers and
 * formats fields for SNMP. If EEPROM access fails, falls back to compiled defaults.
 */

#include "../CONFIG.h"

/* ===== Internal: fetch persisted network config (EEPROM) ===== */

/**
 * @brief Load the persisted network configuration into a caller-provided struct.
 *
 * @param[out] out  Destination struct to receive the persisted configuration.
 *
 * @post On success, @p out fields are populated from EEPROM. On failure, @p out
 *       receives compiled defaults via LoadUserNetworkConfig().
 */
static inline void load_netcfg(networkInfo *out) {
    if (!out)
        return;
    if (!storage_get_network(out)) {
        *out = LoadUserNetworkConfig();
    }
}

/**
 * @brief Format an IPv4 address to dotted decimal.
 *
 * @param[out] ptr  Destination buffer (must be at least 16 bytes).
 * @param[in]  ip   Source IPv4 address as 4 octets.
 *
 * @return Number of characters written excluding the null terminator.
 *
 * @note The output format is "x.x.x.x" and is null-terminated.
 */
static inline uint8_t ipfmt(void *ptr, const uint8_t ip[4]) {
    return (uint8_t)snprintf((char *)ptr, 16, "%u.%u.%u.%u", ip[0], ip[1], ip[2], ip[3]);
}

/* ===== SNMP getters (string-typed) ===== */

/**
 * @brief Get persisted IP address (EEPROM) for SNMP.
 *
 * @param[out] ptr  Output buffer for the string (>=16 bytes recommended).
 * @param[out] len  Number of characters written to @p ptr (excluding null).
 *
 * @pre Storage helpers are initialized.
 * @post @p ptr contains the dotted-decimal IP; @p len reflects byte count.
 */
void get_networkIP(void *ptr, uint8_t *len) {
    networkInfo ni;
    load_netcfg(&ni);
    *len = ipfmt(ptr, ni.ip);
}

/**
 * @brief Get persisted subnet mask (EEPROM) for SNMP.
 *
 * @param[out] ptr  Output buffer for the string (>=16 bytes recommended).
 * @param[out] len  Number of characters written to @p ptr (excluding null).
 *
 * @pre Storage helpers are initialized.
 * @post @p ptr contains the dotted-decimal mask; @p len reflects byte count.
 */
void get_networkMask(void *ptr, uint8_t *len) {
    networkInfo ni;
    load_netcfg(&ni);
    *len = ipfmt(ptr, ni.sn);
}

/**
 * @brief Get persisted gateway (EEPROM) for SNMP.
 *
 * @param[out] ptr  Output buffer for the string (>=16 bytes recommended).
 * @param[out] len  Number of characters written to @p ptr (excluding null).
 *
 * @pre Storage helpers are initialized.
 * @post @p ptr contains the dotted-decimal gateway; @p len reflects byte count.
 */
void get_networkGateway(void *ptr, uint8_t *len) {
    networkInfo ni;
    load_netcfg(&ni);
    *len = ipfmt(ptr, ni.gw);
}

/**
 * @brief Get persisted DNS server (EEPROM) for SNMP.
 *
 * @param[out] ptr  Output buffer for the string (>=16 bytes recommended).
 * @param[out] len  Number of characters written to @p ptr (excluding null).
 *
 * @pre Storage helpers are initialized.
 * @post @p ptr contains the dotted-decimal DNS address; @p len reflects byte count.
 */
void get_networkDNS(void *ptr, uint8_t *len) {
    networkInfo ni;
    load_netcfg(&ni);
    *len = ipfmt(ptr, ni.dns);
}

/** @} */
