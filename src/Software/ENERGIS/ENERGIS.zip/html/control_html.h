// Auto-generated C header file from HTML
#ifndef CONTROL_HTML_H
#define CONTROL_HTML_H

extern const char control_html[];

#endif // CONTROL_HTML_H
