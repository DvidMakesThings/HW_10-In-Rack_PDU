// Auto-generated C header file from HTML
#ifndef USER_MANUAL_HTML_H
#define USER_MANUAL_HTML_H

extern const char user_manual_html[];

#endif // USER_MANUAL_HTML_H
