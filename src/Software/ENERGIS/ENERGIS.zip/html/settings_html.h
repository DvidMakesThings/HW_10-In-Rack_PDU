// Auto-generated C header file from HTML
#ifndef SETTINGS_HTML_H
#define SETTINGS_HTML_H

extern const char settings_html[];

#endif // SETTINGS_HTML_H
