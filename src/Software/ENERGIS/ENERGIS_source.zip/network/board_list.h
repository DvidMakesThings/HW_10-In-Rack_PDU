/* Board list */
#define WIZnet_Ethernet_HAT 0
#define W5100S_EVB_PICO 1
#define W5500_EVB_PICO 2
#define W55RP20_EVB_PICO 3
#define W5100S_EVB_PICO2 4
#define W5500_EVB_PICO2 5