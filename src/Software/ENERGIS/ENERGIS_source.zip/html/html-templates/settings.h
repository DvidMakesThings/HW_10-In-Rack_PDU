// Auto-generated C header file from HTML
#ifndef SETTINGS_HTML_H
#define SETTINGS_HTML_H

#endif // SETTINGS_HTML_H
