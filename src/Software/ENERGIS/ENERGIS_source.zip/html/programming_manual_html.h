// Auto-generated C header file from HTML
#ifndef PROGRAMMING_MANUAL_HTML_H
#define PROGRAMMING_MANUAL_HTML_H

extern const char programming_manual_html[];

#endif // PROGRAMMING_MANUAL_HTML_H
