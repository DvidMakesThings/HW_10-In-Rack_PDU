// Auto-generated C header file from HTML
#ifndef HELP_HTML_H
#define HELP_HTML_H

extern const char help_html[];

#endif // HELP_HTML_H
